import tkinter as tk #for creating a Window
from tkinter import filedialog #allows you to select files from your computer
import pygame
import os
from mutagen.mp3 import MP3
#nitialize pygame mixer
pygame.mixer.init()  #to get the audio working.

#creating Window
Play=tk.Tk() #creates the main window where all the action will happen – the buttons you press
Play.title("Music Player")
Play.geometry("400x300")   # how big you want that window to be when it first opens.


#Creating a Function
def browse_file():
    file_path=filedialog.askopenfilename(filetypes=[("audio files","*.mp3")])

    if file_path:
        pygame.mixer.music.load(file_path)
        pygame.mixer.music.play()

def pause_music():
    pygame.mixer.music.pause()
def resume():
    pygame.mixer.music.unpause()
def stop_music():
    pygame.mixer.music.stop()

# GUI Element
tk.Label(Play, text="Music Player", font=("arial",18)).pack(pady=10)
tk.Button(Play, text="browse &  Play", command=browse_file).pack(pady=5)
tk.Button(Play, text="Pause", command=pause_music).pack(pady=5)
tk.Button(Play, text="Resume", command=resume).pack(pady=5)
tk.Button(Play, text="Stop Music", command=stop_music).pack(pady=5)

Play.mainloop() # till now window hhas been cerated , Now we will add features 

Songs="Songs"
songs=[f for f in os.listdir(Songs) if f.endswith(('.mp3'))]

#List box to show songs
playlist=tk.Listbox(Play)
playlist.pack(pady=10)

for song in Songs:
    playlist.insert(tk.END, song)

#creating a function for selecting music
def select_songs():
    select=playlist.curselection()
    if select:
        selected_songs=playlist.get(select[0])
        full_path=os.path.join(Songs, selected_songs)
        pygame.mixer.music.play()
        song_label.config(text=f"Now Playing : {selected_songs}")

#Add Button
tk.Button(Play, text="Play Selected", command=select_songs).pack(pady=5)
song_label = tk.Label(Play, text="Now Playing : None")
song_label.pack()

#Volume Slider
def change_volume(val):
    volume = int(val) / 100
    pygame.mixer.music.set_volume(volume)

volume_slider = tk.Scale(Play, from_=0, to=100, orient=tk.HORIZONTAL, command=change_volume)
volume_slider.set(70)  # Default volume
volume_slider.pack(pady=5)

audio = MP3(full_path)
length = audio.info.length
minutes = int(length // 60)
seconds = int(length % 60)
song_label.config(text=f"Now Playing: {selected_songs} ({minutes}:{seconds:02d})")
current_index = 0
def next_song():
    global current_index
    current_index = (current_index + 1) % len(songs)
    song = songs[current_index]
    full_path = os.path.join(Songs, song)
    pygame.mixer.music.load(full_path)
    pygame.mixer.music.play()
    playlist.select_clear(0, tk.END)
    playlist.select_set(current_index)
    song_label.config(text=f"Now Playing: {song}")

def prev_song():
    global current_index
    current_index = (current_index - 1) % len(songs)
    song = songs[current_index]
    full_path = os.path.join(Songs, song)
    pygame.mixer.music.load(full_path)
    pygame.mixer.music.play()
    playlist.select_clear(0, tk.END)
    playlist.select_set(current_index)
    song_label.config(text=f"Now Playing: {song}")

tk.Button(Play, text="⏮ Prev", command=prev_song).pack(pady=2)
tk.Button(Play, text="⏭ Next", command=next_song).pack(pady=2)

RECENT_FILE = "recent.txt"

def save_recent(song):
    with open(RECENT_FILE, "a") as f:
        f.write(song + "\n")

def play_selected_song():
    ...
    save_recent(selected_songs)

